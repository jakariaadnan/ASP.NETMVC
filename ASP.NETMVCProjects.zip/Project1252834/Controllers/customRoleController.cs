﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Project1252834.Models;
using Project1252834.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Project1252834.Controllers
{
    [Authorize(Users = "admin@admin.com")]
    public class customRoleController : Controller
    {
        
        ApplicationDbContext db = new ApplicationDbContext();
        // GET: customRole

        public ActionResult Index()
        {

            return View(db.Roles.ToList());
        }
        [Authorize(Users = "admin@admin.com")]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(roleViewModel identity)
        {
            var rol = new IdentityRole
            {
                Id = identity.Id,
                Name = identity.Name
            };
            db.Roles.Add(rol);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult All()
        {
            return View();
        }
        //[Authorize(Users = "admin@admin.com")]
        //public ActionResult Edit(string id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    roleViewModel role = db.roleViewModels.Find(id);
        //    if (role == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(role);
        //}
        //[HttpPost]
        //public ActionResult Edit(roleViewModel identity)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(identity).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(identity);
        //}
        //[Authorize(Users = "admin@admin.com")]
        //public ActionResult Delete()
        //{
        //    return View();
        //}
        [Authorize(Users = "admin@admin.com")]
        [Authorize(Roles ="Admin,Super Admin")]
        [HttpGet]
        public ActionResult AssignRole()
        {
            ViewBag.userList = db.Users.Select(s => new SelectListItem
            {
                Text = s.UserName,
                Value = s.Id
            });
            ViewBag.userRole = db.Roles.Select(s => new SelectListItem
            {
                Text = s.Name,
                Value = s.Name
            });
            return View();
        }

        [HttpPost]
        public ActionResult AssignRole(string userList, string userRole)
        {
            ViewBag.userList = db.Users.Select(s => new SelectListItem { Text = s.UserName, Value = s.Id });
            ViewBag.userRole = db.Roles.Select(s => new SelectListItem { Text = s.Name, Value = s.Name });

            var store = new UserStore<ApplicationUser>(db);
            var uManager = new UserManager<ApplicationUser>(store);
            IdentityResult result = uManager.AddToRole(userList, userRole);
            if (result.Succeeded)
            {
                ViewBag.result = "Successfully Role Assign.";
            }
            else
            {
                ViewBag.result = "Role Assign Failed.";
            }
            return View();
        }
        [HttpGet]
        public ActionResult AssignRoleList()
        {
            ViewBag.userList = db.Users.Select(s => new SelectListItem
            {
                Text = s.UserName,
                Value = s.Id
            });
            return View();
        }

        [HttpPost]
        public ActionResult AssignRoleList(string userList)
        {

            ViewBag.userList = db.Users.Select(s => new SelectListItem
            {
                Text = s.UserName,
                Value = s.Id
            });

            var store = new UserStore<ApplicationUser>(db);
            var uManager = new UserManager<ApplicationUser>(store);
            if (!string.IsNullOrEmpty(userList))
            {
                var roleList = uManager.GetRoles(userList);
                ViewBag.roles = new SelectList(roleList);
            }
            else
            {
                ViewBag.result = "Select User From The List";
            }
            return View();
        }
        public ActionResult GetAlluserRole()
        {
            IEnumerable<UserRolesVM> All = new List<UserRolesVM>();
            All = (from u in db.Users
                   select new
                   {
                       UserID = u.Id,
                       UserName = u.UserName,
                       RoleName = (from ur in u.Roles
                                   join r in db.Roles
                                   on ur.RoleId equals u.Id
                                   select r.Name
                                  )

                   }
                   ).ToList().Select(s => new UserRolesVM
                   {
                       UserID = s.UserID,
                       UserName = s.UserName,
                       RoleName = string.Join(",", s.RoleName)
                   });
            return View(All);
        }
        [Authorize(Users = "admin@admin.com")]
        [Authorize(Roles = "Admin,Super Admin")]
        [HttpGet]
        public ActionResult RemoveUserRole()
        {
            ViewBag.userList = db.Users.Select(s => new SelectListItem
            {
                Text = s.UserName,
                Value = s.Id
            });
            ViewBag.roleList = db.Roles.Select(s => new SelectListItem
            {
                Text = s.Name,
                Value = s.Id
            });

            return View();
        }

        [HttpPost]
        public ActionResult RemoveUserRole(string userList, string roleList)
        {
            ViewBag.userList = db.Users.Select(s => new SelectListItem
            {
                Text = s.UserName,
                Value = s.Id
            });
            ViewBag.roleList = db.Roles.Select(s => new SelectListItem
            {
                Text = s.Name,
                Value = s.Name
            });
            var store = new UserStore<ApplicationUser>(db);
            var uManager = new UserManager<ApplicationUser>(store);
            IdentityResult result = uManager.RemoveFromRole(userList, roleList);
            if (result.Succeeded)
            {
                ViewBag.result = "Role Remove Successfully.";
            }
            else
            {
                ViewBag.result = "Error Occured";
            }

            return View();
        }

    }
}