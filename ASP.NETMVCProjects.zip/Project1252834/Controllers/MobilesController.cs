﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Project1252834;
using Project1252834.Models;
using PagedList;

namespace Project1252834.Controllers
{
    public class MobilesController : Controller
    {
        private OnlineShopEntities db = new OnlineShopEntities();

        // GET: Mobiles
        //public ActionResult Index()
        //{
        //    return View(db.Mobiles.ToList());
        //}
        public ActionResult Index(string sortOrder, string SearchString, string currentFilter, int? page)
        {
            ViewBag.MobileCompanySortParm = string.IsNullOrEmpty(sortOrder) ? "MobileCompany_desc" : "";
            ViewBag.ModelNameSortParm = string.IsNullOrEmpty(sortOrder) ? "ModelName_desc" : "";
            if (SearchString != null)
            {
                page = 1;
            }
            else
            {
                SearchString = currentFilter;
            }
            ViewBag.CurrentFilter = SearchString;

            var mobile = from d in db.Mobiles
                         select d;
            if (!string.IsNullOrEmpty(SearchString))
            {
                mobile = mobile.Where(s =>
                    s.MobileCompany.ToUpper().Contains(SearchString.ToUpper())
                    ||
                    s.ModelName.ToUpper().Contains(SearchString.ToUpper())
                    );
            }

            switch (sortOrder)
            {
                case "MobileCompany_desc":
                    mobile = mobile.OrderByDescending(s => s.MobileCompany);
                    break;
                case "ModelName_desc":
                    mobile = mobile.OrderByDescending(s => s.ModelName);
                    break;
                default:
                    mobile = mobile.OrderBy(s => s.MobileCompany);
                    break;
            }
            int pageSize = 3;
            int pageNumber = (page ?? 1);
            return View(mobile.ToPagedList(pageNumber, pageSize));
        }

        // GET: Mobiles/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Mobile mobile = db.Mobiles.Find(id);
            if (mobile == null)
            {
                return HttpNotFound();
            }
            return View(mobile);
        }

        // GET: Mobiles/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Mobiles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Mobile mobile)
        {
            if (ModelState.IsValid)
            {
                if (mobile.imagefile != null)
                {
                    string ext = Path.GetExtension(mobile.imagefile.FileName).ToLower();
                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png")
                    {
                        string filename = Path.GetFileNameWithoutExtension(mobile.imagefile.FileName) + "_" + Guid.NewGuid().ToString() + ext;
                        mobile.imagefile.SaveAs(Path.Combine(Server.MapPath("~/upload"), filename));

                        mobile.Photo = "~/Upload/" + filename;
                    }
                }
                db.Mobiles.Add(mobile);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(mobile);
        }

        // GET: Mobiles/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Mobile mobile = db.Mobiles.Find(id);
            if (mobile == null)
            {
                return HttpNotFound();
            }
            return View(mobile);
        }

        // POST: Mobiles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,MobileCompany,ModelName,RAM,Camera,Price,ReleaseYear,Photo")] Mobile mobile)
        {
            if (ModelState.IsValid)
            {
                db.Entry(mobile).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(mobile);
        }

        // GET: Mobiles/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Mobile mobile = db.Mobiles.Find(id);
            if (mobile == null)
            {
                return HttpNotFound();
            }
            return View(mobile);
        }

        // POST: Mobiles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Mobile mobile = db.Mobiles.Find(id);
            db.Mobiles.Remove(mobile);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
