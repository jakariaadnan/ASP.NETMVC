﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project1252834.ViewModel
{
    public class UserRolesVM
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }
    }
}