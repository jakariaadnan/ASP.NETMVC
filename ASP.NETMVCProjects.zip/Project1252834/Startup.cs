﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Project1252834.Startup))]
namespace Project1252834
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
